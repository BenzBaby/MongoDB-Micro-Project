<?php
require_once __DIR__ . '/vendor/autoload.php';

$client = new MongoDB\Client('mongodb://localhost:27017');
$db = $client->student;
$collection = $db->student;

// Check if the form is submitted
if (isset($_POST['is_submit'])) {
    try {
        // Get the student ID from the URL parameter
        $studentId = $_GET['id'];

        // Update the student's information in the database
        $updateResult = $collection->updateOne(
            ['_id' => new MongoDB\BSON\ObjectID($studentId)],
            ['$set' => [
                'name' => $_POST['name'],
                'mobno' => $_POST['mobno'],
                'address' => $_POST['address'],
                'age' => $_POST['age'],
           
            ]]
        );

        if ($updateResult->getModifiedCount() > 0) {
            echo '<script>alert("student information updated successfully!");</script>';
        } else {
            echo '<script>alert("No changes made to student information.");</script>';
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}

// Retrieve the student's information
$studentId = $_GET['id'];
$student = $collection->findOne(['_id' => new MongoDB\BSON\ObjectID($studentId)]);
?>

<html>
<head>
<title>Update student</title>
</head>
<body>
<h2>Update student Information</h2>
<form method="post">
    <table>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name" value="<?php echo $student['name']; ?>"></td>
        </tr>
        <tr>
            <td>Mob No:</td>
            <td><input type="text" name="mobno" value="<?php echo $student['mobno']; ?>"></td>
        </tr>
        <tr>
            <td>Address:</td>
            <td><input type="text" name="address" value="<?php echo $student['address']; ?>"></td>
        </tr>
        <tr>
            <td>Age:</td>
            <td><input type="text" name="age" value="<?php echo $student['age']; ?>"></td>
        </tr>
       
        <tr>
            <td></td>
            <td><input type="submit" value="Update" name="is_submit"></td>
        </tr>
    </table>
</form>
<a href="view.php">View Updated</a>
<a href="view.php">Back</a>
</body>
</html>
